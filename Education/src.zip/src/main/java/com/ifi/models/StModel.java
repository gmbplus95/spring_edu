package com.ifi.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="student")
public class StModel {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="studentid")
	public int studentid;

	@Column(name="studentname")
	public String studentName;
	@Column(name="studentage")
	public String studentAge;
	@Column(name="studentlocation")
	public String studentLocation;
	
	
	public StModel() {
		super();
	}
	public StModel(String studentName, String studentAge, String studentLocation) {
		super();
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.studentLocation = studentLocation;
	}
	
	
	
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentAge() {
		return studentAge;
	}
	public void setStudentAge(String studentAge) {
		this.studentAge = studentAge;
	}
	public String getStudentLocation() {
		return studentLocation;
	}
	public void setStudentLocation(String studentLocation) {
		this.studentLocation = studentLocation;
	}
	
	
}