package com.ifi.models;

import org.springframework.data.repository.CrudRepository;

public interface CourseRepo extends CrudRepository<CourseModel, Integer>{

}
