package com.ifi.models;
import org.springframework.data.repository.CrudRepository;
public interface StudentRepo extends CrudRepository<StModel, Integer>{

}
