package com.ifi.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ifi.models.StModel;
import com.ifi.models.StudentRepo;

@Controller
public class MainController {
	@Autowired
	StudentRepo studentRepo;
	@RequestMapping("/")
	public String goHome(Model model){
		model.addAttribute("listStudent", studentRepo.findAll());	
		return "index";
		}
	
	@PostMapping(value= "/save_st")
	public ModelAndView saveSt(
			@RequestParam("studentName") String studentName,
			@RequestParam("studentAge") String studentAge,
			@RequestParam("studentLocation") String studentLocation) {
		ModelAndView mv=new ModelAndView("redirect:/");
		StModel stModel=new StModel();
		stModel.setStudentName(studentName);
		stModel.setStudentAge(studentAge);
		stModel.setStudentLocation(studentLocation);
		studentRepo.save(stModel);
		return mv;	
	}
	
	@GetMapping(value="/view_st/{studentid}")
	public ModelAndView viewSt(@PathVariable("studentid") int studentid){
		ModelAndView mv=new ModelAndView("View");
		mv.addObject("listStudent",studentRepo.findById(studentid));
		return mv;
	}
	
	@GetMapping(value="/delete_st/{studentid}")
	public ModelAndView deleteSt(@PathVariable("studentid") int studentid){
		ModelAndView mv=new ModelAndView("redirect:/");
		studentRepo.deleteById(studentid);
		return mv;
	}
	
	@GetMapping(value="/edit_st/{studentid}")
	public String editSt(@PathVariable("studentid") int studentid,Model model){
		model.addAttribute("listStudent",studentRepo.findById(studentid));
		return "edit";
	}
}
	